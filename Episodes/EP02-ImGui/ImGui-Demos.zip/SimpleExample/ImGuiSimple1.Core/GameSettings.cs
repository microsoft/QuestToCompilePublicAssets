﻿using Microsoft.Xna.Framework;

namespace ImGuiSimple1;

public static class GameSettings
{
    public static Color ClearColor = Color.MediumOrchid;
}
