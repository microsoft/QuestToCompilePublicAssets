﻿using Microsoft.Xna.Framework;
using Numerics = System.Numerics;
using Hexa.NET.ImGui;
using System;

namespace ImGuiSimple1;

internal class ImGuiComponent(Game game) : DrawableGameComponent(game)
{
    private ImGuiRenderer _imGuiRenderer;

    public static Action<ImGuiRenderer>? RenderCallback;

    public override void Initialize()
    {
        _imGuiRenderer = new ImGuiRenderer(Game);

        DrawOrder = 99;
        UpdateOrder = 99;

        base.Initialize();
    }

    public override void Draw(GameTime gameTime)
    {
        // Call BeforeLayout first to set things up
        _imGuiRenderer.BeforeLayout(gameTime);

        // Draw the ImGui objects
        RenderCallback?.Invoke(_imGuiRenderer);

        // Call AfterLayout now to finish up and draw all the things
        _imGuiRenderer.AfterLayout();
    }

    protected override void UnloadContent()
    {
        _imGuiRenderer?.Dispose();
    }

    float _floatValue = 0.5f;
}
