﻿using Microsoft.Xna.Framework;
using Numerics = System.Numerics;
using Hexa.NET.ImGui;

namespace ImGuiSimple1.Scenes;

internal class ClearColor(Game game) : DrawableGameComponent(game)
{
    protected override void UnloadContent()
    {
        if (ImGuiComponent.RenderCallback == DrawImGuiObjects)
            ImGuiComponent.RenderCallback = null;
    }

    protected override void LoadContent()
    {
        ImGuiComponent.RenderCallback = DrawImGuiObjects;
    }

    void DrawImGuiObjects(ImGuiRenderer renderer)
    {
        if (ImGui.Begin("Change Settings"u8))
        {
            if (ImGui.Button("Go Back"u8))
            {
                this.Dispose();
                Game.Components.Remove(this);
                Game.Components.Add(new Root(Game));
            }

            ImGui.Separator();

            ImGui.Text("Hello, world!"u8);
            
            ImGui.Separator();

            Numerics.Vector3 clearColor = new((float)GameSettings.ClearColor.R / 255,
                                              (float)GameSettings.ClearColor.G / 255,
                                              (float)GameSettings.ClearColor.B / 255);

            if (ImGui.ColorEdit3("Game Clear Color", ref clearColor))
                GameSettings.ClearColor = new(clearColor.X, clearColor.Y, clearColor.Z);

            ImGui.Separator();
            ImGui.ColorButton("Color1"u8, Color1);
            ImGui.SameLine();
            ImGui.ColorButton("Color2"u8, Color2);
            ImGui.SameLine();
            ImGui.ColorButton("Color3"u8, Color3);
            ImGui.SameLine();
            ImGui.ColorButton("Color4"u8, Color4);
            ImGui.SameLine();
            ImGui.ColorButton("Color5"u8, Color5);
            ImGui.SameLine();
        }
        ImGui.End();
    }

    private Numerics.Vector4 Color1 =>
        new((float)Color.Yellow.R / 255,
            (float)Color.Yellow.G / 255,
            (float)Color.Yellow.B / 255,
            1f);

    private Numerics.Vector4 Color2 =>
        new((float)Color.Cyan.R / 255,
            (float)Color.Cyan.G / 255,
            (float)Color.Cyan.B / 255,
            1f);

    private Numerics.Vector4 Color3 =>
        new((float)Color.Magenta.R / 255,
            (float)Color.Magenta.G / 255,
            (float)Color.Magenta.B / 255,
            1f);

    private Numerics.Vector4 Color4 =>
        new((float)Color.White.R / 255,
            (float)Color.White.G / 255,
            (float)Color.White.B / 255,
            1f);

    private Numerics.Vector4 Color5 =>
        new((float)Color.Orange.R / 255,
            (float)Color.Orange.G / 255,
            (float)Color.Orange.B / 255,
            1f);
}
