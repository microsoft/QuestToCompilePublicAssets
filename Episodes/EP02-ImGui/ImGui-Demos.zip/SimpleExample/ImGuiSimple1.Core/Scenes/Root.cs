﻿using Hexa.NET.ImGui;
using Microsoft.Xna.Framework;

namespace ImGuiSimple1.Scenes;

internal class Root(Game game) : DrawableGameComponent(game)
{
    protected override void UnloadContent()
    {
        if (ImGuiComponent.RenderCallback == DrawImGuiObjects)
            ImGuiComponent.RenderCallback = null;
    }

    protected override void LoadContent()
    {
        ImGuiComponent.RenderCallback = DrawImGuiObjects;
    }

    float _floatValue = 0.5f;

    void DrawImGuiObjects(ImGuiRenderer renderer)
    {
        if (ImGui.Begin("Select Scene"u8))
        {
            if (ImGui.Button("Scene Demo"u8))
            {
                this.Dispose();
                Game.Components.Remove(this);
                Game.Components.Add(new DemoWindow(Game));
            }

            if (ImGui.Button("Scene 1: Change Clear Color"u8))
            {
                this.Dispose();
                Game.Components.Remove(this);
                Game.Components.Add(new ClearColor(Game));
            }

            if (ImGui.Button("Scene 2: Edit Sprite"u8))
            {
                this.Dispose();
                Game.Components.Remove(this);
                Game.Components.Add(new SpriteScene(Game));
            }

            if (ImGui.Button("Scene 3: Edit Sprite Scene"u8))
            {
                this.Dispose();
                Game.Components.Remove(this);
                Game.Components.Add(new MultiSpriteScene(Game));
            }

        }
        ImGui.End();
    }
}
