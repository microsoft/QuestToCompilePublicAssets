﻿using Microsoft.Xna.Framework;
using Numerics = System.Numerics;
using Hexa.NET.ImGui;
using Microsoft.Xna.Framework.Graphics;
using System;

namespace ImGuiSimple1.Scenes;

internal class MultiSpriteScene(Game game) : DrawableGameComponent(game)
{
    private class SpriteData(string name, Texture2D texture, Numerics.Vector2 position, Numerics.Vector4 color)
    {
        public string Name = name;
        public Texture2D Texture = texture;
        public bool IsVisible = true;
        public Numerics.Vector2 Position = position;
        public float Scale = 1.0f;
        public Numerics.Vector4 Color = color;
        public SpriteEffects Effects = SpriteEffects.None;
    }

    private readonly SpriteData[] _sprites = CreateSprites();
    private int _selectedIndex = 0;
    private SpriteBatch _spriteBatch;

    private static SpriteData[] CreateSprites()
    {
        var sprites = new SpriteData[6];

        for (int i = 0; i < sprites.Length; i++)
        {
            float hue = i / 10f;
            Numerics.Vector4 color = HueToRgba(hue);
            Numerics.Vector2 position = new(50 + i * 80, 100);
            sprites[i] = new SpriteData($"Sprite {i}", SharedAssets.CarWhite, position, color);
        }

        return sprites;
    }

    private static Numerics.Vector4 HueToRgba(float hue)
    {
        float r, g, b;
        float h = hue * 6f;
        float f = h - (float)Math.Floor(h);

        switch ((int)h % 6)
        {
            case 0: r = 1; g = f; b = 0; break;
            case 1: r = 1 - f; g = 1; b = 0; break;
            case 2: r = 0; g = 1; b = f; break;
            case 3: r = 0; g = 1 - f; b = 1; break;
            case 4: r = f; g = 0; b = 1; break;
            default: r = 1; g = 0; b = 1 - f; break;
        }

        return new Numerics.Vector4(r, g, b, 1f);
    }

    protected override void UnloadContent()
    {
        if (ImGuiComponent.RenderCallback == DrawImGuiObjects)
            ImGuiComponent.RenderCallback = null;
    }

    protected override void LoadContent()
    {
        ImGuiComponent.RenderCallback = DrawImGuiObjects;
    }

    public override void Initialize()
    {
        _spriteBatch = new SpriteBatch(GraphicsDevice);

        base.Initialize();
    }

    public override void Draw(GameTime gameTime)
    {
        _spriteBatch.Begin();

        foreach (var sprite in _sprites)
        {
            if (!sprite.IsVisible) continue;

            _spriteBatch.Draw(
                sprite.Texture,
                new Vector2(sprite.Position.X, sprite.Position.Y),
                null,
                new Color(sprite.Color.X, sprite.Color.Y, sprite.Color.Z, sprite.Color.W),
                0f,
                Vector2.Zero,
                sprite.Scale,
                sprite.Effects,
                0f);
        }

        _spriteBatch.End();
    }

    void DrawImGuiObjects(ImGuiRenderer renderer)
    {
        if (ImGui.Begin("Sprite Settings"u8))
        {
            if (ImGui.Button("Go Back"u8))
            {
                this.Dispose();
                Game.Components.Remove(this);
                Game.Components.Add(new Root(Game));
            }

            ImGui.Separator();

            ImGui.Text("Sprites"u8);

            if (ImGui.BeginListBox("##sprite-list"u8))
            {
                for (int i = 0; i < _sprites.Length; i++)
                {
                    bool isSelected = _selectedIndex == i;

                    if (ImGui.Selectable(_sprites[i].Name, isSelected))
                        _selectedIndex = i;

                    if (isSelected)
                        ImGui.SetItemDefaultFocus();
                }

                ImGui.EndListBox();
            }

            ImGui.Separator();

            ref SpriteData selected = ref _sprites[_selectedIndex];

            ImGui.Text(selected.Name);

            ImGui.Checkbox("Is Visible"u8, ref selected.IsVisible);

            ImGui.DragFloat2("Position", ref selected.Position, 1.0f);
            ImGui.DragFloat("Scale", ref selected.Scale, 0.01f, 0.1f, 10.0f);
            ImGui.ColorEdit4("Shade Color", ref selected.Color);

            bool flipH = selected.Effects.HasFlag(SpriteEffects.FlipHorizontally);
            bool flipV = selected.Effects.HasFlag(SpriteEffects.FlipVertically);

            if (ImGui.Checkbox("Flip Horizontal"u8, ref flipH))
                selected.Effects ^= SpriteEffects.FlipHorizontally;

            if (ImGui.Checkbox("Flip Vertical"u8, ref flipV))
                selected.Effects ^= SpriteEffects.FlipVertically;

            var drawList = ImGui.GetBackgroundDrawList();

            drawList.AddRect(
                new Numerics.Vector2(selected.Position.X, selected.Position.Y),
                new Numerics.Vector2(selected.Position.X + selected.Texture.Width * selected.Scale, selected.Position.Y + selected.Texture.Height * selected.Scale),
                ImGui.GetColorU32(new Numerics.Vector4(1, 1, 1, 1)));
        }
        ImGui.End();
    }
}
