﻿using Microsoft.Xna.Framework;
using Numerics = System.Numerics;
using Hexa.NET.ImGui;

namespace ImGuiSimple1.Scenes;

internal class DemoWindow(Game game) : DrawableGameComponent(game)
{
    protected override void UnloadContent()
    {
        if (ImGuiComponent.RenderCallback == DrawImGuiObjects)
            ImGuiComponent.RenderCallback = null;
    }

    protected override void LoadContent()
    {
        ImGuiComponent.RenderCallback = DrawImGuiObjects;
    }

    void DrawImGuiObjects(ImGuiRenderer renderer)
    {
        

        ImGui.ShowDemoWindow();

        if (ImGui.Begin("Dear ImGui Demo"))
        //if (ImGui.Begin("Manage App Window"))
        {
            if (ImGui.Button("Go Back"u8))
            {
                this.Dispose();
                Game.Components.Remove(this);
                Game.Components.Add(new Root(Game));
            }
        }
        ImGui.End();

    }
}
