﻿using Microsoft.Xna.Framework;
using Numerics = System.Numerics;
using Hexa.NET.ImGui;
using Microsoft.Xna.Framework.Graphics;

namespace ImGuiSimple1.Scenes;

internal class SpriteScene(Game game) : DrawableGameComponent(game)
{
    private bool _isSpriteVisible = true;
    private Numerics.Vector2 _spritePosition = new(100, 100);
    private float _spriteScale = 1.0f;
    private Numerics.Vector4 _spriteColor = new(1f, 1f, 1f, 1f);
    private SpriteEffects _spriteEffects = SpriteEffects.None;
    private SpriteBatch _spriteBatch;

    protected override void UnloadContent()
    {
        if (ImGuiComponent.RenderCallback == DrawImGuiObjects)
            ImGuiComponent.RenderCallback = null;
    }

    protected override void LoadContent()
    {
        ImGuiComponent.RenderCallback = DrawImGuiObjects;
    }

    public override void Initialize()
    {
        _spriteBatch = new SpriteBatch(GraphicsDevice);

        base.Initialize();
    }

    public override void Draw(GameTime gameTime)
    {
        if (_isSpriteVisible)
        {
            _spriteBatch.Begin();
            _spriteBatch.Draw(
                SharedAssets.CarWhite,
                new Vector2(_spritePosition.X, _spritePosition.Y),
                null,
                new Color(_spriteColor.X, _spriteColor.Y, _spriteColor.Z, _spriteColor.W),
                0f,
                Vector2.Zero,
                _spriteScale,
                _spriteEffects,
                0f);
            _spriteBatch.End();
        }
    }

    void DrawImGuiObjects(ImGuiRenderer renderer)
    {
        if (ImGui.Begin("Sprite Settings"u8))
        {
            if (ImGui.Button("Go Back"u8))
            {
                this.Dispose();
                Game.Components.Remove(this);
                Game.Components.Add(new Root(Game));
            }

            ImGui.Separator();

            ImGui.Text("Sprite Settings"u8);

            ImGui.Checkbox("Is Visible"u8, ref _isSpriteVisible);

            ImGui.DragFloat2("Position", ref _spritePosition, 1.0f);
            ImGui.DragFloat("Scale", ref _spriteScale, 0.01f, 0.1f, 10.0f);
            ImGui.ColorEdit4("Shade Color", ref _spriteColor);

            bool flipH = _spriteEffects.HasFlag(SpriteEffects.FlipHorizontally);
            bool flipV = _spriteEffects.HasFlag(SpriteEffects.FlipVertically);

            if (ImGui.Checkbox("Flip Horizontal"u8, ref flipH))
                _spriteEffects ^= SpriteEffects.FlipHorizontally;

            if (ImGui.Checkbox("Flip Vertical"u8, ref flipV))
                _spriteEffects ^= SpriteEffects.FlipVertically;
        }
        ImGui.End();
    }
}
