﻿using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Text;

namespace ImGuiSimple1;

public static class SharedAssets
{
    public static Texture2D CarWhite;
}
