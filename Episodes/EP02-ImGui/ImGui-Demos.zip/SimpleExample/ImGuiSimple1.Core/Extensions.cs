﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Graphics;

namespace ImGuiSimple1;

/// <summary>
/// Extensions for the <see cref="Texture2D"/> type.
/// </summary>
public static class MonoGame_TextureExtensions
{


    /// <summary>
    /// Saves a texture to a png file.
    /// </summary>
    /// <param name="target">The texture.</param>
    /// <param name="path">The path to a png file.</param>
    public static void Save(this Texture2D target, string path)
    {
        using (System.IO.FileStream stream = System.IO.File.OpenWrite(path))
        {
            target.SaveAsPng(stream, target.Bounds.Width, target.Bounds.Height);
        }
    }
}
