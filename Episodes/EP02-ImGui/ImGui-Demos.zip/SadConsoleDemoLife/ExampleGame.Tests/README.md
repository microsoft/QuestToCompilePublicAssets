# ExampleGame.Tests

Unit tests for the SimAnt colony simulation layer.

## Running Tests

```bash
cd ExampleGame.Tests
dotnet test
```

## Test Coverage

- **DirectionTests** — 8-direction system, rotations, sense cone
- **GridTests** — bounds, cell operations, nest placement  
- **PheromoneLayerTests** — dual pheromone types, decay, diffusion
- **AntTests** — ant struct data integrity
- **AntManagerTests** — ant lifecycle, movement, food collection
- **FoodManagerTests** — cluster spawning, pickup/dropoff
- **ColonySimulationTests** — end-to-end simulation, stability

**Total:** 62 tests, all passing

## Design

Tests verify behavior, not implementation. Edge cases and boundary conditions are prioritized. The 1000-tick stress test ensures simulation stability under load.
