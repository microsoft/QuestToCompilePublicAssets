using ExampleGame.Simulation;
using Xunit;

namespace ExampleGame.Tests.Simulation;

public class AntTests
{
    [Fact]
    public void Ant_StoresPositionCorrectly()
    {
        var ant = new Ant
        {
            X = 10,
            Y = 20,
            DirectionIndex = 3,
            CarryingFood = false
        };
        
        Assert.Equal(10, ant.X);
        Assert.Equal(20, ant.Y);
        Assert.Equal(3, ant.DirectionIndex);
        Assert.False(ant.CarryingFood);
    }

    [Fact]
    public void Ant_CarryingFood_TogglesCorrectly()
    {
        var ant = new Ant
        {
            X = 10,
            Y = 10,
            DirectionIndex = 0,
            CarryingFood = false
        };
        
        Assert.False(ant.CarryingFood);
        
        ant.CarryingFood = true;
        Assert.True(ant.CarryingFood);
        
        ant.CarryingFood = false;
        Assert.False(ant.CarryingFood);
    }

    [Fact]
    public void Ant_DirectionIndex_StoresCorrectly()
    {
        var ant = new Ant { DirectionIndex = 5 };
        Assert.Equal(5, ant.DirectionIndex);
        
        ant.DirectionIndex = 0;
        Assert.Equal(0, ant.DirectionIndex);
        
        ant.DirectionIndex = 7;
        Assert.Equal(7, ant.DirectionIndex);
    }

    [Fact]
    public void Ant_StepsSinceFood_Increments()
    {
        var ant = new Ant
        {
            X = 0,
            Y = 0,
            DirectionIndex = 0,
            CarryingFood = true,
            StepsSinceFood = 0
        };
        
        Assert.Equal(0, ant.StepsSinceFood);
        
        ant.StepsSinceFood++;
        Assert.Equal(1, ant.StepsSinceFood);
        
        ant.StepsSinceFood += 10;
        Assert.Equal(11, ant.StepsSinceFood);
    }
}
