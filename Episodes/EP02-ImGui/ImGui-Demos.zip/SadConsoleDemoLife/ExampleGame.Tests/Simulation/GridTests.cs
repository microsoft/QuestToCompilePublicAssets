using ExampleGame.Simulation;
using Xunit;

namespace ExampleGame.Tests.Simulation;

public class GridTests
{
    [Fact]
    public void Grid_InitializesWithCorrectDimensions()
    {
        var grid = new Grid(50, 30);
        
        Assert.Equal(50, grid.Width);
        Assert.Equal(30, grid.Height);
    }

    [Theory]
    [InlineData(0, 0, true)]
    [InlineData(49, 29, true)]
    [InlineData(25, 15, true)]
    [InlineData(-1, 0, false)]
    [InlineData(0, -1, false)]
    [InlineData(50, 0, false)]
    [InlineData(0, 30, false)]
    [InlineData(100, 100, false)]
    public void IsInBounds_ReturnsCorrectValue(int x, int y, bool expected)
    {
        var grid = new Grid(50, 30);
        
        Assert.Equal(expected, grid.IsInBounds(x, y));
    }

    [Fact]
    public void Nest_IsPlacedAtCenter()
    {
        var grid = new Grid(50, 30);
        
        Assert.Equal(25, grid.NestX);
        Assert.Equal(15, grid.NestY);
        Assert.Equal(CellType.Nest, grid.GetCell(25, 15));
    }

    [Fact]
    public void DefaultCells_AreEmpty()
    {
        var grid = new Grid(50, 30);
        
        // Check several random cells (but not nest)
        Assert.Equal(CellType.Empty, grid.GetCell(0, 0));
        Assert.Equal(CellType.Empty, grid.GetCell(10, 10));
        Assert.Equal(CellType.Empty, grid.GetCell(49, 29));
    }

    [Fact]
    public void CanSetAndGetCellTypes()
    {
        var grid = new Grid(50, 30);
        
        grid.SetCell(10, 10, CellType.Wall);
        Assert.Equal(CellType.Wall, grid.GetCell(10, 10));
        
        grid.SetCell(20, 20, CellType.Empty);
        Assert.Equal(CellType.Empty, grid.GetCell(20, 20));
    }

    [Fact]
    public void SetCell_OutOfBounds_DoesNotCrash()
    {
        var grid = new Grid(50, 30);
        
        // These should not throw exceptions
        grid.SetCell(-1, 0, CellType.Wall);
        grid.SetCell(0, -1, CellType.Wall);
        grid.SetCell(100, 100, CellType.Wall);
    }

    [Fact]
    public void GetCell_OutOfBounds_ReturnsWall()
    {
        var grid = new Grid(50, 30);
        
        Assert.Equal(CellType.Wall, grid.GetCell(-1, 0));
        Assert.Equal(CellType.Wall, grid.GetCell(0, -1));
        Assert.Equal(CellType.Wall, grid.GetCell(100, 100));
    }
}
