using ExampleGame.Simulation;
using Xunit;

namespace ExampleGame.Tests.Simulation;

public class DirectionTests
{
    [Theory]
    [InlineData(0, 0, -1)]   // North
    [InlineData(1, 1, -1)]   // NorthEast
    [InlineData(2, 1, 0)]    // East
    [InlineData(3, 1, 1)]    // SouthEast
    [InlineData(4, 0, 1)]    // South
    [InlineData(5, -1, 1)]   // SouthWest
    [InlineData(6, -1, 0)]   // West
    [InlineData(7, -1, -1)]  // NorthWest
    public void AllDirections_HaveCorrectDxDy(int dirIndex, int expectedDx, int expectedDy)
    {
        var (dx, dy) = Direction.GetForward(dirIndex);
        Assert.Equal(expectedDx, dx);
        Assert.Equal(expectedDy, dy);
    }

    [Fact]
    public void TurnLeft45_CyclesThroughAllDirections()
    {
        int dir = 0; // Start North
        var visited = new HashSet<int>();
        
        for (int i = 0; i < 8; i++)
        {
            visited.Add(dir);
            dir = Direction.TurnLeft45(dir);
        }
        
        // Should have visited all 8 directions
        Assert.Equal(8, visited.Count);
        // Should return to start after 8 turns
        Assert.Equal(0, dir);
    }

    [Fact]
    public void TurnRight45_CyclesThroughAllDirections()
    {
        int dir = 0; // Start North
        var visited = new HashSet<int>();
        
        for (int i = 0; i < 8; i++)
        {
            visited.Add(dir);
            dir = Direction.TurnRight45(dir);
        }
        
        // Should have visited all 8 directions
        Assert.Equal(8, visited.Count);
        // Should return to start after 8 turns
        Assert.Equal(0, dir);
    }

    [Fact]
    public void GetSenseCone_ReturnsThreeCells()
    {
        int x = 10, y = 10;
        int dirIndex = 0; // North
        
        var cone = Direction.GetSenseCone(x, y, dirIndex);
        
        Assert.Equal(3, cone.Length);
        
        // For North (0,-1), cone should be: NW, N, NE
        // NorthWest: (9, 9), North: (10, 9), NorthEast: (11, 9)
        Assert.Contains((9, 9), cone);
        Assert.Contains((10, 9), cone);
        Assert.Contains((11, 9), cone);
    }

    [Fact]
    public void FullRotation_EightLeftTurns_ReturnsToOriginal()
    {
        int original = 3; // Start at SouthEast
        int dir = original;
        
        for (int i = 0; i < 8; i++)
        {
            dir = Direction.TurnLeft45(dir);
        }
        
        Assert.Equal(original, dir);
    }

    [Fact]
    public void FullRotation_EightRightTurns_ReturnsToOriginal()
    {
        int original = 5; // Start at SouthWest
        int dir = original;
        
        for (int i = 0; i < 8; i++)
        {
            dir = Direction.TurnRight45(dir);
        }
        
        Assert.Equal(original, dir);
    }

    [Theory]
    [InlineData(10, 10, 10, 0, 0)]   // Target due north → direction 0
    [InlineData(10, 10, 20, 10, 2)]  // Target due east → direction 2
    [InlineData(10, 10, 10, 20, 4)]  // Target due south → direction 4
    [InlineData(10, 10, 0, 10, 6)]   // Target due west → direction 6
    [InlineData(10, 10, 20, 0, 1)]   // Target northeast → direction 1
    [InlineData(10, 10, 0, 20, 5)]   // Target southwest → direction 5
    public void DirectionToward_ReturnsCorrectCardinalAndDiagonal(
        int fromX, int fromY, int toX, int toY, int expectedDir)
    {
        int dir = Direction.DirectionToward(fromX, fromY, toX, toY);
        Assert.Equal(expectedDir, dir);
    }

    [Fact]
    public void DirectionToward_SamePoint_ReturnsValidDirection()
    {
        // When from == to, should return a random but valid direction (0-7)
        for (int i = 0; i < 20; i++)
        {
            int dir = Direction.DirectionToward(5, 5, 5, 5);
            Assert.InRange(dir, 0, 7);
        }
    }

    [Fact]
    public void DirectionToward_ResultMovesTowardTarget()
    {
        int fromX = 10, fromY = 10, toX = 20, toY = 5;
        int dir = Direction.DirectionToward(fromX, fromY, toX, toY);
        var (dx, dy) = Direction.GetForward(dir);

        // Moving in the returned direction should reduce distance to target
        int oldDist = Math.Abs(toX - fromX) + Math.Abs(toY - fromY);
        int newDist = Math.Abs(toX - (fromX + dx)) + Math.Abs(toY - (fromY + dy));
        Assert.True(newDist < oldDist, "Moving toward target should reduce Manhattan distance");
    }
}
