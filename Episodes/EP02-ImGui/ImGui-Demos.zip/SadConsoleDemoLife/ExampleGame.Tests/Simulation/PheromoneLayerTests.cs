using ExampleGame.Simulation;
using Xunit;

namespace ExampleGame.Tests.Simulation;

public class PheromoneLayerTests
{
    [Fact]
    public void Deposit_IncreasesStrengthAtCell()
    {
        var layer = new PheromoneLayer(50, 30, SimConfig.PheromoneDecayRate, SimConfig.PheromoneDiffusionRate);
        
        float initialStrength = layer.GetStrength(10, 10, PheromoneType.FoodTrail);
        layer.Deposit(10, 10, 5.0f, PheromoneType.FoodTrail);
        float newStrength = layer.GetStrength(10, 10, PheromoneType.FoodTrail);
        
        Assert.True(newStrength > initialStrength);
        Assert.Equal(initialStrength + 5.0f, newStrength, precision: 2);
    }

    [Fact]
    public void Decay_ReducesAllValuesByDecayRate()
    {
        var layer = new PheromoneLayer(50, 30, SimConfig.PheromoneDecayRate, SimConfig.PheromoneDiffusionRate);
        
        // Deposit pheromone
        layer.Deposit(10, 10, 100.0f, PheromoneType.FoodTrail);
        float beforeDecay = layer.GetStrength(10, 10, PheromoneType.FoodTrail);
        
        // Tick once (decay happens)
        layer.Tick();
        float afterDecay = layer.GetStrength(10, 10, PheromoneType.FoodTrail);
        
        // Should be less than before
        Assert.True(afterDecay < beforeDecay);
        
        // After decay: value *= (1 - decayRate)
        Assert.True(afterDecay > 0); // Should not be zero after one tick
        Assert.True(afterDecay < beforeDecay);
    }

    [Fact]
    public void AfterManyTicks_PheromonesApproachZero()
    {
        var layer = new PheromoneLayer(50, 30, SimConfig.PheromoneDecayRate, SimConfig.PheromoneDiffusionRate);
        
        layer.Deposit(10, 10, 100.0f, PheromoneType.FoodTrail);
        
        // Run for many ticks
        for (int i = 0; i < 1000; i++)
        {
            layer.Tick();
        }
        
        float finalStrength = layer.GetStrength(10, 10, PheromoneType.FoodTrail);
        
        // After 1000 ticks of decay, should be very close to zero
        Assert.True(finalStrength < 0.01f);
    }

    [Fact]
    public void Diffusion_SpreadsPheromones()
    {
        var layer = new PheromoneLayer(50, 30, SimConfig.PheromoneDecayRate, SimConfig.PheromoneDiffusionRate);
        
        // Deposit high concentration at center
        layer.Deposit(25, 15, 100.0f, PheromoneType.FoodTrail);
        
        // Check neighbors before tick
        float neighborBefore = layer.GetStrength(25, 14, PheromoneType.FoodTrail);
        
        // Tick (decay + diffusion)
        layer.Tick();
        
        // Check neighbors after tick
        float neighborAfter = layer.GetStrength(25, 14, PheromoneType.FoodTrail);
        
        // Neighbor should have increased due to diffusion
        Assert.True(neighborAfter > neighborBefore);
    }

    [Fact]
    public void PheromoneValues_NeverGoNegative()
    {
        var layer = new PheromoneLayer(50, 30, SimConfig.PheromoneDecayRate, SimConfig.PheromoneDiffusionRate);
        
        // Start with zero, tick many times
        for (int i = 0; i < 100; i++)
        {
            layer.Tick();
        }
        
        // Check several cells
        for (int x = 0; x < 50; x += 10)
        {
            for (int y = 0; y < 30; y += 10)
            {
                Assert.True(layer.GetStrength(x, y, PheromoneType.FoodTrail) >= 0);
                Assert.True(layer.GetStrength(x, y, PheromoneType.HomeTrail) >= 0);
            }
        }
    }

    [Fact]
    public void GetStrength_OutOfBounds_ReturnsZero()
    {
        var layer = new PheromoneLayer(50, 30, SimConfig.PheromoneDecayRate, SimConfig.PheromoneDiffusionRate);
        
        Assert.Equal(0, layer.GetStrength(-1, 0, PheromoneType.FoodTrail));
        Assert.Equal(0, layer.GetStrength(0, -1, PheromoneType.FoodTrail));
        Assert.Equal(0, layer.GetStrength(100, 100, PheromoneType.FoodTrail));
    }

    [Fact]
    public void Deposit_OutOfBounds_DoesNotCrash()
    {
        var layer = new PheromoneLayer(50, 30, SimConfig.PheromoneDecayRate, SimConfig.PheromoneDiffusionRate);
        
        // These should not throw exceptions
        layer.Deposit(-1, 0, 10.0f, PheromoneType.FoodTrail);
        layer.Deposit(0, -1, 10.0f, PheromoneType.FoodTrail);
        layer.Deposit(100, 100, 10.0f, PheromoneType.FoodTrail);
    }

    [Fact]
    public void BothPheromoneTypes_WorkIndependently()
    {
        var layer = new PheromoneLayer(50, 30, SimConfig.PheromoneDecayRate, SimConfig.PheromoneDiffusionRate);
        
        layer.Deposit(10, 10, 50.0f, PheromoneType.FoodTrail);
        layer.Deposit(10, 10, 25.0f, PheromoneType.HomeTrail);
        
        Assert.Equal(50.0f, layer.GetStrength(10, 10, PheromoneType.FoodTrail), precision: 1);
        Assert.Equal(25.0f, layer.GetStrength(10, 10, PheromoneType.HomeTrail), precision: 1);
    }

    [Fact]
    public void PheromoneDecay_ActuallyReducesStrengthSignificantly()
    {
        var layer = new PheromoneLayer(50, 30, SimConfig.PheromoneDecayRate, SimConfig.PheromoneDiffusionRate);
        
        // Deposit a strong pheromone
        float initialStrength = 100.0f;
        layer.Deposit(25, 15, initialStrength, PheromoneType.FoodTrail);
        
        // Run 50 ticks (5 seconds at 10 ticks/sec)
        for (int i = 0; i < 50; i++)
        {
            layer.Tick();
        }
        
        float afterDecay = layer.GetStrength(25, 15, PheromoneType.FoodTrail);
        
        // With decay rate, after 50 ticks: strength *= (1 - decayRate)^50
        // At 0.02 rate: 100 * 0.98^50 = ~36.4
        // At 0.05 rate: 100 * 0.95^50 = ~7.7
        // At 0.08 rate: 100 * 0.92^50 = ~1.4
        // Should be significantly less than initial (less than 50%)
        Assert.True(afterDecay < initialStrength * 0.5f, 
            $"After 50 ticks, pheromone should decay to less than 50% of initial. Initial: {initialStrength}, After: {afterDecay}");
        Assert.True(afterDecay > 0, "Pheromone should not reach zero after only 50 ticks");
    }
}
