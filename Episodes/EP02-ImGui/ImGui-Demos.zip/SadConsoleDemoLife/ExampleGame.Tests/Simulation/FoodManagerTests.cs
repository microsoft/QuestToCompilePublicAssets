using ExampleGame.Simulation;
using Xunit;

namespace ExampleGame.Tests.Simulation;

public class FoodManagerTests
{
    [Fact]
    public void SpawnFoodCluster_PlacesFoodOnGrid()
    {
        var grid = new Grid(50, 30);
        var manager = new FoodManager(50, 30);
        
        int totalBefore = manager.GetTotalFoodRemaining();
        manager.SpawnFoodCluster(grid, 10, 10, 5);
        int totalAfter = manager.GetTotalFoodRemaining();
        
        // Food spawning uses random distribution, so just check that some food was added
        Assert.True(totalAfter >= totalBefore);
        // Check that food exists somewhere near the spawn point
        bool foodFound = false;
        for (int x = 7; x <= 13 && !foodFound; x++)
        {
            for (int y = 7; y <= 13 && !foodFound; y++)
            {
                if (manager.GetFoodAt(x, y) > 0)
                    foodFound = true;
            }
        }
        Assert.True(foodFound);
    }

    [Fact]
    public void TryPickup_RemovesFoodFromCell()
    {
        var grid = new Grid(50, 30);
        var manager = new FoodManager(50, 30);
        
        manager.SpawnFoodCluster(grid, 10, 10, 10);
        
        // Find a cell with food (spawning is random in clusters)
        int foodX = -1, foodY = -1;
        for (int x = 7; x <= 13; x++)
        {
            for (int y = 7; y <= 13; y++)
            {
                if (manager.GetFoodAt(x, y) > 0)
                {
                    foodX = x;
                    foodY = y;
                    break;
                }
            }
            if (foodX >= 0) break;
        }
        
        Assert.True(foodX >= 0, "Should have spawned food in cluster");
        
        int foodBefore = manager.GetFoodAt(foodX, foodY);
        bool success = manager.TryPickup(foodX, foodY);
        
        Assert.True(success);
        Assert.Equal(foodBefore - 1, manager.GetFoodAt(foodX, foodY));
    }

    [Fact]
    public void TryPickup_OnEmptyCell_ReturnsFalse()
    {
        var manager = new FoodManager(50, 30);
        
        bool success = manager.TryPickup(10, 10);
        
        Assert.False(success);
    }

    [Fact]
    public void TryDropoff_OnlyWorksAtNest()
    {
        var grid = new Grid(50, 30);
        var manager = new FoodManager(50, 30);
        
        // Should succeed at nest
        bool successAtNest = manager.TryDropoff(grid.NestX, grid.NestY, grid);
        Assert.True(successAtNest);
        
        // Should fail away from nest
        bool successAway = manager.TryDropoff(10, 10, grid);
        Assert.False(successAway);
    }

    [Fact]
    public void TotalFoodRemaining_TracksCorrectly()
    {
        var grid = new Grid(50, 30);
        var manager = new FoodManager(50, 30);
        
        int initial = manager.GetTotalFoodRemaining();
        manager.SpawnFoodCluster(grid, 10, 10, 10);
        
        // Should be at least initial + some food (may be less than 10 due to clustering)
        Assert.True(manager.GetTotalFoodRemaining() > initial);
        
        manager.TryPickup(10, 10);
        int afterPickup = manager.GetTotalFoodRemaining();
        Assert.True(afterPickup < manager.GetTotalFoodRemaining() + 1);
    }

    [Fact]
    public void TotalFoodCollected_IncrementsOnDropoff()
    {
        var grid = new Grid(50, 30);
        var manager = new FoodManager(50, 30);
        
        int collected = manager.TotalFoodCollected;
        
        manager.TryDropoff(grid.NestX, grid.NestY, grid);
        Assert.Equal(collected + 1, manager.TotalFoodCollected);
        
        manager.TryDropoff(grid.NestX, grid.NestY, grid);
        Assert.Equal(collected + 2, manager.TotalFoodCollected);
    }

    [Fact]
    public void FoodClusters_DontSpawnOnNest()
    {
        var grid = new Grid(50, 30);
        var manager = new FoodManager(50, 30);
        
        // Try to spawn at nest location
        manager.SpawnFoodCluster(grid, grid.NestX, grid.NestY, 10);
        
        // Food should not be at nest
        int foodAtNest = manager.GetFoodAt(grid.NestX, grid.NestY);
        Assert.Equal(0, foodAtNest);
    }

    [Fact]
    public void InitializeFood_PlacesMultipleClusters()
    {
        var grid = new Grid(50, 30);
        var manager = new FoodManager(50, 30);
        
        int before = manager.GetTotalFoodRemaining();
        manager.InitializeFood(grid);
        
        Assert.True(manager.GetTotalFoodRemaining() > before);
    }

    [Fact]
    public void GetFoodAt_OutOfBounds_ReturnsZero()
    {
        var manager = new FoodManager(50, 30);
        
        Assert.Equal(0, manager.GetFoodAt(-1, 0));
        Assert.Equal(0, manager.GetFoodAt(0, -1));
        Assert.Equal(0, manager.GetFoodAt(100, 100));
    }
}
