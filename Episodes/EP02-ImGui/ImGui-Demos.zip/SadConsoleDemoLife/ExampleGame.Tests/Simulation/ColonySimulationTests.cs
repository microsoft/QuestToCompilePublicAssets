using ExampleGame.Simulation;
using Xunit;

namespace ExampleGame.Tests.Simulation;

public class ColonySimulationTests
{
    [Fact]
    public void Initialize_CreatesGridAndPlacesNest()
    {
        var sim = new ColonySimulation();
        sim.Initialize();
        
        Assert.NotNull(sim.Grid);
        Assert.Equal(SimConfig.GridWidth, sim.Grid.Width);
        Assert.Equal(SimConfig.GridHeight, sim.Grid.Height);
        
        // Nest should be at center
        Assert.Equal(CellType.Nest, sim.Grid.GetCell(sim.Grid.NestX, sim.Grid.NestY));
    }

    [Fact]
    public void Initialize_SpawnsAnts()
    {
        var sim = new ColonySimulation();
        sim.Initialize();
        
        Assert.NotNull(sim.AntManager);
        Assert.True(sim.AntManager.Ants.Count > 0);
    }

    [Fact]
    public void Initialize_PlacesFood()
    {
        var sim = new ColonySimulation();
        sim.Initialize();
        
        Assert.NotNull(sim.FoodManager);
        Assert.True(sim.FoodManager.GetTotalFoodRemaining() > 0);
    }

    [Fact]
    public void Initialize_CreatesPheromoneLayer()
    {
        var sim = new ColonySimulation();
        sim.Initialize();
        
        Assert.NotNull(sim.PheromoneLayer);
    }

    [Fact]
    public void Tick_AdvancesSimulationState()
    {
        var sim = new ColonySimulation();
        sim.Initialize();
        
        // Get initial ant positions
        var initialPositions = sim.AntManager.Ants
            .Select(a => (a.X, a.Y))
            .ToList();
        
        // Tick multiple times
        for (int i = 0; i < 20; i++)
        {
            sim.Tick();
        }
        
        // At least one ant should have moved
        var currentPositions = sim.AntManager.Ants
            .Select(a => (a.X, a.Y))
            .ToList();
        
        bool anyMoved = false;
        for (int i = 0; i < initialPositions.Count; i++)
        {
            if (initialPositions[i] != currentPositions[i])
            {
                anyMoved = true;
                break;
            }
        }
        
        Assert.True(anyMoved, "At least one ant should have moved after multiple ticks");
    }

    [Fact]
    public void MultipleTicks_DontCrash()
    {
        var sim = new ColonySimulation();
        sim.Initialize();
        
        // Run for a reasonable number of ticks
        for (int i = 0; i < 100; i++)
        {
            sim.Tick();
        }
        
        // If we got here, no crash occurred
        Assert.True(true);
    }

    [Fact]
    public void Simulation_Runs1000TicksWithoutException()
    {
        var sim = new ColonySimulation();
        sim.Initialize();
        
        var exception = Record.Exception(() =>
        {
            for (int i = 0; i < 1000; i++)
            {
                sim.Tick();
            }
        });
        
        Assert.Null(exception);
    }

    [Fact]
    public void Pheromones_DecayOverTime()
    {
        var sim = new ColonySimulation();
        sim.Initialize();
        
        // Deposit some pheromone
        sim.PheromoneLayer.Deposit(10, 10, 100.0f, PheromoneType.FoodTrail);
        float initial = sim.PheromoneLayer.GetStrength(10, 10, PheromoneType.FoodTrail);
        
        // Tick many times - each tick processes ants AND pheromones
        for (int i = 0; i < 100; i++)
        {
            sim.Tick();
        }
        
        float after = sim.PheromoneLayer.GetStrength(10, 10, PheromoneType.FoodTrail);
        
        // Should have decayed (but ants may also deposit, so check it's significantly less)
        // With 100 ticks and decay rate of 0.02, should be much less than initial
        Assert.True(after <= initial, $"Pheromone should have decayed or stayed same. Initial: {initial}, After: {after}");
    }

    [Fact]
    public void FoodCollection_IncreasesOverTime()
    {
        var sim = new ColonySimulation();
        sim.Initialize();
        
        int initialCollected = sim.FoodManager.TotalFoodCollected;
        
        // Run simulation for many ticks
        for (int i = 0; i < 500; i++)
        {
            sim.Tick();
        }
        
        int finalCollected = sim.FoodManager.TotalFoodCollected;
        
        // At least some food should have been collected (may fail if unlucky, but very unlikely)
        Assert.True(finalCollected >= initialCollected);
    }
}
