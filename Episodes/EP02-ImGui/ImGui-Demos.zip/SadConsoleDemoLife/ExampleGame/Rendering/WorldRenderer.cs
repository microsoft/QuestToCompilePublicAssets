using ExampleGame.Simulation;

namespace ExampleGame.Rendering;

/// <summary>
/// Reads simulation state and writes to a ScreenSurface.
/// No allocations in the render loop.
/// </summary>
class WorldRenderer
{
    private readonly ScreenSurface _surface;

    public WorldRenderer(ScreenSurface surface)
    {
        _surface = surface;
    }

    /// <summary>
    /// Render the simulation state to the screen surface.
    /// Multi-pass: terrain → food → pheromones → ants.
    /// </summary>
    public void Render(ColonySimulation sim)
    {
        int width = sim.Grid.Width;
        int height = sim.Grid.Height;

        // Draw the main map layers first (terrain, food, pheromones)
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {

                // Pass 1: Terrain base layer
                var cellType = sim.Grid.GetCell(x, y);
                var (glyph, foreground) = GlyphPalette.GetTerrainAppearance(cellType);

                _surface.Surface[x, y].Glyph = glyph;
                _surface.Surface[x, y].Foreground = foreground;
                _surface.Surface[x, y].Background = GlyphPalette.BackgroundColor;

                // Pass 2: Food overlay
                int foodQuantity = sim.FoodManager.GetFoodAt(x, y);
                if (foodQuantity > 0)
                {
                    (glyph, foreground) = GlyphPalette.GetFoodAppearance();
                    _surface.Surface[x, y].Glyph = glyph;
                    _surface.Surface[x, y].Foreground = foreground;
                }

                // Pass 3: Pheromone visualization (blend into background)
                float foodStrength = sim.PheromoneLayer.GetStrength(x, y, PheromoneType.FoodTrail);
                float homeStrength = sim.PheromoneLayer.GetStrength(x, y, PheromoneType.HomeTrail);

                if (foodStrength > 0.01f || homeStrength > 0.01f)
                {
                    var blendedBackground = GlyphPalette.BlendPheromoneBackground(foodStrength, homeStrength);
                    _surface.Surface[x, y].Background = blendedBackground;
                }


            }
        }

        // Pass 3.5: Nest visibility overlay (visual-only 3x3 beacon)
        int nestX = sim.Grid.NestX;
        int nestY = sim.Grid.NestY;
        for (int dy = -1; dy <= 1; dy++)
        {
            for (int dx = -1; dx <= 1; dx++)
            {
                int nx = nestX + dx;
                int ny = nestY + dy;
                if (sim.Grid.IsInBounds(nx, ny))
                {
                    _surface.Surface[nx, ny].Background = GlyphPalette.NestBackgroundColor;
                    if (dx == 0 && dy == 0)
                    {
                        _surface.Surface[nx, ny].Glyph = GlyphPalette.Nest;
                        _surface.Surface[nx, ny].Foreground = GlyphPalette.NestColor;
                    }
                    else
                    {
                        _surface.Surface[nx, ny].Glyph = GlyphPalette.Nest;
                        _surface.Surface[nx, ny].Foreground = GlyphPalette.NestGlowColor;
                    }
                }
            }
        }

        // Pass 4: Ants on top
        foreach (var ant in sim.AntManager.Ants)
        {
            var (glyph, foreground) = GlyphPalette.GetAntAppearance(ant);
            _surface.Surface[ant.X, ant.Y].Glyph = glyph;
            _surface.Surface[ant.X, ant.Y].Foreground = foreground;
        }

        _surface.IsDirty = true;
    }
}
