using ExampleGame.Simulation;
using SadConsole.Quick;
using SadConsole.UI;

namespace ExampleGame.Rendering;

/// <summary>
/// Main screen object for the colony simulation.
/// Owns simulation, renderer, and handles input/update loop.
/// </summary>
class SimulationScreen : ScreenObject
{
    private readonly ScreenSurface _surface;
    private ColonySimulation _simulation;
    private readonly WorldRenderer _renderer;
    private Window? _legendWindow;

    private TimeSpan _timeAccumulator;
    private TimeSpan _tickInterval;
    private bool _isPaused;

    // Speed control
    private const double MinTicksPerSecond = 1.0;
    private const double MaxTicksPerSecond = 60.0;
    private double _ticksPerSecond = SimConfig.SimTicksPerSecond;

    public SimulationScreen()
    {
        // Create the world surface
        _surface = new ScreenSurface(GameSettings.GAME_WIDTH, GameSettings.GAME_HEIGHT);
        _surface.UseMouse = false;
        Children.Add(_surface);

        // Create and initialize simulation
        _simulation = new ColonySimulation();
        _simulation.Initialize();
        _renderer = new WorldRenderer(_surface);

        // Initialize timing
        _tickInterval = TimeSpan.FromSeconds(1.0 / _ticksPerSecond);
        _timeAccumulator = TimeSpan.Zero;
        _isPaused = false;

        // Enable input
        IsFocused = true;
        UseKeyboard = true;
        UseMouse = true;

        // Initial render
        _renderer.Render(_simulation);
    }

    public override void Update(TimeSpan delta)
    {
        base.Update(delta);

        // Check debug window pause state
        var debugWin = GetDebugWindow();
        bool shouldPause = _isPaused || (debugWin?.IsPaused ?? false);

        if (debugWin != null && debugWin.IsResetRequested)
        {
            debugWin.IsResetRequested = false;
            ResetSimulation();
            _timeAccumulator = TimeSpan.Zero;
        }

        if (!shouldPause)
        {
            // Time accumulator pattern for fixed-rate simulation ticks
            _timeAccumulator += delta;

            while (_timeAccumulator >= _tickInterval)
            {
                _simulation.Tick();
                _timeAccumulator -= _tickInterval;
            }
        }

        // Is paused, but tick step requested by debug window
        else if (debugWin != null && debugWin.IsTickRequested)
        {
            debugWin.IsTickRequested = false;
            _simulation.Tick();
        }

        // Render every frame
        _renderer.Render(_simulation);
    }

    public override bool ProcessKeyboard(SadConsole.Input.Keyboard keyboard)
    {
        // ?: show legend
        if (keyboard.IsKeyPressed(SadConsole.Input.Keys.OemQuestion))
        {
            ShowLegend();
            return true;
        }

        // Space: pause/resume
        if (keyboard.IsKeyPressed(SadConsole.Input.Keys.Space))
        {
            _isPaused = !_isPaused;
            
            // Sync debug window pause state
            var debugWin = GetDebugWindow();
            if (debugWin != null)
            {
                debugWin.IsPaused = _isPaused;
            }
            return true;
        }

        // +/=: speed up
        if (keyboard.IsKeyPressed(SadConsole.Input.Keys.OemPlus) || keyboard.IsKeyPressed(SadConsole.Input.Keys.Add))
        {
            _ticksPerSecond = Math.Min(_ticksPerSecond * 1.5, MaxTicksPerSecond);
            _tickInterval = TimeSpan.FromSeconds(1.0 / _ticksPerSecond);
            return true;
        }

        // -: slow down
        if (keyboard.IsKeyPressed(SadConsole.Input.Keys.OemMinus) || keyboard.IsKeyPressed(SadConsole.Input.Keys.Subtract))
        {
            _ticksPerSecond = Math.Max(_ticksPerSecond / 1.5, MinTicksPerSecond);
            _tickInterval = TimeSpan.FromSeconds(1.0 / _ticksPerSecond);
            return true;
        }

        // R: reset simulation
        if (keyboard.IsKeyPressed(SadConsole.Input.Keys.R))
        {
            ResetSimulation();
            return true;
        }

        // F12: toggle debug window
        if (keyboard.IsKeyPressed(SadConsole.Input.Keys.F12))
        {
            ToggleDebugWindow();
            return true;
        }

        return base.ProcessKeyboard(keyboard);
    }

    public override bool ProcessMouse(SadConsole.Input.MouseScreenObjectState state)
    {
        // Click-to-select ant when debug window is visible
        var debugWin = GetDebugWindow();
        if (debugWin?.IsVisible == true)
        {
            state = new(_surface, state.Mouse);

            if (state.Mouse.LeftClicked)
            {
                // Get the click position in surface coordinates
                var surfacePos = state.SurfaceCellPosition;
                int clickX = surfacePos.X;
                int clickY = surfacePos.Y;

                // Find any ant at this position
                for (int i = 0; i < _simulation.AntManager.Ants.Count; i++)
                {
                    var ant = _simulation.AntManager.Ants[i];
                    if (ant.X == clickX && ant.Y == clickY)
                    {
                        _simulation.AntManager.SelectAnt(i);
                        debugWin.SelectedAntIndex = i;
                        return true;
                    }
                }

                debugWin.SelectedAntIndex = -1;
            }
            if (state.Mouse.LeftButtonDown && debugWin.IsDrawing)
            {
                var surfacePos = state.SurfaceCellPosition;
                int clickX = surfacePos.X;
                int clickY = surfacePos.Y;

                if (debugWin.DrawStyle == 0)
                    _simulation.Grid.SetCell(state.SurfaceCellPosition.X, state.SurfaceCellPosition.Y, CellType.Wall);

                else if (debugWin.DrawStyle == 1)
                    _simulation.FoodManager.SetFoodAt(clickX, clickY, 1, _simulation.Grid);
            }
        }

        return base.ProcessMouse(state);
    }

    public void ResetSimulation()
    {
        _simulation = new ColonySimulation();
        _simulation.Initialize();
        _timeAccumulator = TimeSpan.Zero;
        _renderer.Render(_simulation);
        // Update debug window reference if active
        var debugWin = GetDebugWindow();
        if (debugWin != null)
        {
            debugWin.Simulation = _simulation;
            debugWin.SelectedAntIndex = -1;
        }
    }

    private void ShowLegend()
    {
        // Create a window centered on screen
        int windowWidth = 50;
        int windowHeight = 14;
        int windowX = (GameSettings.GAME_WIDTH - windowWidth) / 2;
        int windowY = (GameSettings.GAME_HEIGHT - windowHeight) / 2;

        if (_legendWindow == null)
        {
            _legendWindow = new Window(windowWidth, windowHeight)
            {
                Position = new Point(windowX, windowY),
                Title = " Legend ",
                CanDrag = false,
                IsModalDefault = true,
                CloseOnEscKey = true,
            };

            _legendWindow.WithKeyboard((scr, keyboard) => {
                if (keyboard.IsKeyPressed(SadConsole.Input.Keys.Space) ||
                    keyboard.IsKeyPressed(SadConsole.Input.Keys.OemQuestion))
                {
                    _legendWindow.Hide();
                    return true;
                }
                return false;
            });

            _legendWindow.Closed += (s, e) => {
                _isPaused = false;
            };
            
            Children.Add(_legendWindow);
        }

        // Write legend content
        int row = 1;

        _legendWindow.Surface.Print(2, row++, "Glyphs and Colors:", Color.Yellow);
        row++;
        _legendWindow.Surface.Print(2, row++, "\x04  = Nest (brown/orange)", new Color(180, 100, 40));
        _legendWindow.Surface.Print(2, row++, "A  = Ant carrying food (lime)", Color.LimeGreen);
        _legendWindow.Surface.Print(2, row++, "a  = Ant searching (white)", Color.White);
        _legendWindow.Surface.Print(2, row++, "%  = Food (green)", Color.Green);
        _legendWindow.Surface.Print(2, row++, "#  = Wall (gray)", Color.Gray);
        row++;
        _legendWindow.Surface.Print(2, row++, "Blue tint   = Food pheromone", new Color(0, 100, 200));
        _legendWindow.Surface.Print(2, row++, "Yellow tint = Home pheromone", new Color(200, 180, 0));
        row++;
        _legendWindow.Surface.Print(2, row++, "Press Space to close", Color.White);

        _legendWindow.Show();

        _isPaused = true;
    }

    private void ToggleDebugWindow()
    {
        var debugWin = GetDebugWindow();

        if (debugWin == null)
            return;

        debugWin.IsVisible = !debugWin.IsVisible;
        debugWin.Simulation = _simulation;
    }

    private DebugWindow? GetDebugWindow()
    {
        return Game.Instance.MonoGameInstance.Components
            .OfType<SadConsole.ImGuiSystem.ImGuiMonoGameComponent>()
            .FirstOrDefault()?.UIComponents.OfType<DebugWindow>().FirstOrDefault();
    }
}
