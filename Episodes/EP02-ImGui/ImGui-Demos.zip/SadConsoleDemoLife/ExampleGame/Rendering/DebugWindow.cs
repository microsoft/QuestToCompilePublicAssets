using ExampleGame.Simulation;
using Hexa.NET.ImGui;
using SadConsole.ImGuiSystem;
using System.Numerics;

namespace ExampleGame.Rendering;

/// <summary>
/// ImGui debug window displaying simulation stats.
/// Toggled via F12 key.
/// </summary>
internal class DebugWindow : ImGuiObjectBase
{
    public ColonySimulation? Simulation { get; set; }
    public bool IsPaused { get; set; }

    public bool IsResetRequested { get; set; }
    public bool IsTickRequested { get; set; }
    public bool IsDrawing;
    public int DrawStyle;
    public int SelectedAntIndex { get; set; } = -1;

    public DebugWindow()
    {
        IsVisible = false;
    }

    public override void BuildUI(ImGuiRenderer renderer)
    {
        if (!IsVisible)
            return;

        if (ImGui.Begin("Colony Diagnostics"))
        {
            if (Simulation == null)
            {
                ImGui.Text("No simulation loaded");
                ImGui.End();
                return;
            }

            // === Icon Start ===
            ImGui.PushFont(ImGui.GetIO().Fonts.Fonts[0]);

            // === Pause Toggle ===
            bool pauseToggle = false;

            float buttonSize = ImGui.GetFrameHeight();
            Vector2 squareButtonSize = new(buttonSize, buttonSize);
            if (IsPaused)
                pauseToggle = ImGui.Button("\uf04b"u8, squareButtonSize);
            else
                pauseToggle = ImGui.Button("\U000f03e4"u8, squareButtonSize);

            if (pauseToggle) IsPaused = !IsPaused;
            
            // === Restart ===
            ImGui.SameLine();
            if (ImGui.Button("\uead2"u8, squareButtonSize)) IsResetRequested = true;

            // === Step Logic Once ===
            ImGui.SameLine();
            if (ImGui.Button("\U000f04d7"u8, squareButtonSize)) IsTickRequested = true;

            // === Step Logic Once ===
            ImGui.Checkbox("Draw Mode"u8, ref IsDrawing);
            ImGui.BeginDisabled(!IsDrawing);
            ImGui.SameLine();
            ImGui.Combo("##drawmode_combo", ref DrawStyle, "\U000f07fe Wall\0\U000f025a Food");
            ImGui.EndDisabled();

            // === Icon End ===
            ImGui.PopFont();
            ImGui.Separator();

            var stats = AnalyzeAnts();

            // === Population Summary ===
            if (ImGui.CollapsingHeader("Population", ImGuiTreeNodeFlags.DefaultOpen))
            {
                ImGui.Text($"Total Ants: {stats.TotalAnts}");
                ImGui.SameLine();
                ImGui.TextColored(new System.Numerics.Vector4(0.5f, 1f, 0.5f, 1f), $"  Searching: {stats.Searching}");
                ImGui.SameLine();
                ImGui.TextColored(new System.Numerics.Vector4(1f, 0.8f, 0.2f, 1f), $"  Carrying: {stats.Carrying}");
            }

            // === Behavioral Breakdown ===
            if (ImGui.CollapsingHeader("Ant Behaviors", ImGuiTreeNodeFlags.DefaultOpen))
            {
                ImGui.Indent();
                
                ImGui.TextColored(new System.Numerics.Vector4(0.5f, 1f, 0.5f, 1f), "Searching Ants:");
                ImGui.Text($"  Near Food: {stats.SearchingNearFood}");
                ImGui.Text($"  Following FoodTrail: {stats.SearchingFollowingTrail}");
                ImGui.Text($"  Wandering: {stats.SearchingWandering}");
                
                ImGui.Spacing();
                ImGui.TextColored(new System.Numerics.Vector4(1f, 0.8f, 0.2f, 1f), "Carrying Ants:");
                ImGui.Text($"  Near Nest: {stats.CarryingNearNest}");
                ImGui.Text($"  Following HomeTrail: {stats.CarryingFollowingTrail}");
                ImGui.Text($"  Direct Navigation: {stats.CarryingDirectNav}");
                
                ImGui.Unindent();
            }

            // === Food Statistics ===
            if (ImGui.CollapsingHeader("Food", ImGuiTreeNodeFlags.DefaultOpen))
            {
                int foodRemaining = Simulation.FoodManager.GetTotalFoodRemaining();
                int foodCollected = Simulation.FoodManager.TotalFoodCollected;
                int totalFood = foodRemaining + foodCollected;
                float collectionRate = totalFood > 0 ? (float)foodCollected / totalFood : 0f;

                ImGui.Text($"Collected: {foodCollected}");
                ImGui.Text($"Remaining: {foodRemaining}");
                ImGui.Text($"Total Spawned: {totalFood}");
                
                if (totalFood > 0)
                {
                    ImGui.ProgressBar(collectionRate, new System.Numerics.Vector2(200, 0), $"{collectionRate * 100:F1}%");
                }
            }

            // === Pheromone Statistics (optional) ===
            if (ImGui.CollapsingHeader("Pheromone Trails"))
            {
                ImGui.Text($"Avg FoodTrail: {stats.AvgFoodTrail:F2}");
                ImGui.Text($"Avg HomeTrail: {stats.AvgHomeTrail:F2}");
                ImGui.Text($"Peak FoodTrail: {stats.MaxFoodTrail:F1}");
                ImGui.Text($"Peak HomeTrail: {stats.MaxHomeTrail:F1}");
            }

            // === Ant Selection ===
            if (ImGui.CollapsingHeader("Ant Selection", ImGuiTreeNodeFlags.DefaultOpen))
            {
                // Listbox of all ants
                if (ImGui.BeginListBox("##AntList", new System.Numerics.Vector2(-1, 200)))
                {
                    for (int i = 0; i < Simulation.AntManager.Ants.Count; i++)
                    {
                        var ant = Simulation.AntManager.Ants[i];
                        string antName = !string.IsNullOrEmpty(ant.Name) ? ant.Name : $"Ant #{i}";
                        string label = $"#{i}: {antName}";
                        
                        if (ImGui.Selectable(label, SelectedAntIndex == i))
                        {
                            SelectedAntIndex = i;
                            Simulation.AntManager.SelectAnt(i);
                        }
                    }
                    ImGui.EndListBox();
                }

                // Selected ant details
                if (SelectedAntIndex >= 0 && SelectedAntIndex < Simulation.AntManager.Ants.Count)
                {
                    ImGui.Spacing();
                    ImGui.Separator();
                    ImGui.Spacing();
                    
                    var selectedAnt = Simulation.AntManager.Ants[SelectedAntIndex];
                    string selectedName = !string.IsNullOrEmpty(selectedAnt.Name) ? selectedAnt.Name : $"Ant #{SelectedAntIndex}";
                    
                    ImGui.TextColored(new System.Numerics.Vector4(1f, 1f, 0.5f, 1f), $"Selected: {selectedName}");
                    ImGui.Spacing();
                    
                    ImGui.Text($"Position: ({selectedAnt.X}, {selectedAnt.Y})");
                    
                    string dirArrow = GetDirectionArrow(selectedAnt.DirectionIndex);
                    string dirName = GetDirectionName(selectedAnt.DirectionIndex);
                    ImGui.Text($"Direction: {dirArrow} {dirName}");
                    
                    ImGui.Text($"State: {(selectedAnt.CarryingFood ? "Carrying Food" : "Searching")}");
                    ImGui.Text($"Steps Since Nest: {selectedAnt.StepsSinceNest}");
                    ImGui.Text($"Steps Since Food: {selectedAnt.StepsSinceFood}");
                    
                    ImGui.Spacing();
                    var thought = GetAntThought(selectedAnt, Simulation.Grid, Simulation.PheromoneLayer);
                    ImGui.TextWrapped($"Thought: {thought}");

                    ImGui.BeginDisabled(selectedAnt.IsDead);
                    if (ImGui.Button("Kill")) Simulation.AntManager.KillAnt(SelectedAntIndex);
                    ImGui.EndDisabled();
                }
                else if (SelectedAntIndex >= Simulation.AntManager.Ants.Count)
                {
                    // Selection became invalid (ant count decreased)
                    SelectedAntIndex = -1;
                }
            }
        }
        ImGui.End();
    }

    private struct AntStats
    {
        public int TotalAnts;
        public int Searching;
        public int Carrying;
        public int SearchingNearFood;
        public int SearchingFollowingTrail;
        public int SearchingWandering;
        public int CarryingNearNest;
        public int CarryingFollowingTrail;
        public int CarryingDirectNav;
        public float AvgFoodTrail;
        public float AvgHomeTrail;
        public float MaxFoodTrail;
        public float MaxHomeTrail;
    }

    private AntStats AnalyzeAnts()
    {
        var stats = new AntStats();
        
        if (Simulation == null)
            return stats;

        var ants = Simulation.AntManager.Ants;
        var grid = Simulation.Grid;
        var pheromones = Simulation.PheromoneLayer;

        stats.TotalAnts = ants.Count;

        // Single-pass ant analysis
        foreach (var ant in ants)
        {
            if (ant.CarryingFood)
            {
                stats.Carrying++;
                
                // Classify carrying behavior
                int nestDist = Math.Abs(ant.X - grid.NestX) + Math.Abs(ant.Y - grid.NestY);
                
                if (nestDist <= SimConfig.NestDetectionRange)
                {
                    stats.CarryingNearNest++;
                }
                else
                {
                    // Check if following HomeTrail
                    float homeStrength = pheromones.GetStrength(ant.X, ant.Y, PheromoneType.HomeTrail);
                    if (homeStrength > 1f)
                        stats.CarryingFollowingTrail++;
                    else
                        stats.CarryingDirectNav++;
                }
            }
            else
            {
                stats.Searching++;
                
                // Classify searching behavior
                // Check if near food (approximate via distance to nest and steps)
                bool nearFood = false;
                int foodCheckRange = SimConfig.FoodDetectionRange;
                for (int dx = -foodCheckRange; dx <= foodCheckRange && !nearFood; dx++)
                {
                    for (int dy = -foodCheckRange; dy <= foodCheckRange && !nearFood; dy++)
                    {
                        if (dx * dx + dy * dy <= foodCheckRange * foodCheckRange)
                        {
                            if (Simulation.FoodManager.GetFoodAt(ant.X + dx, ant.Y + dy) > 0)
                            {
                                nearFood = true;
                            }
                        }
                    }
                }

                if (nearFood)
                {
                    stats.SearchingNearFood++;
                }
                else
                {
                    // Check if following FoodTrail
                    float foodStrength = pheromones.GetStrength(ant.X, ant.Y, PheromoneType.FoodTrail);
                    if (foodStrength > 1f)
                        stats.SearchingFollowingTrail++;
                    else
                        stats.SearchingWandering++;
                }
            }
        }

        // Sample pheromone strengths (sample grid to avoid full scan)
        SamplePheromones(ref stats);

        return stats;
    }

    private void SamplePheromones(ref AntStats stats)
    {
        if (Simulation == null)
            return;

        var pheromones = Simulation.PheromoneLayer;
        var grid = Simulation.Grid;
        
        // Sample every 10th cell for efficiency
        int sampleCount = 0;
        float foodSum = 0f;
        float homeSum = 0f;
        
        for (int x = 0; x < grid.Width; x += 10)
        {
            for (int y = 0; y < grid.Height; y += 10)
            {
                float food = pheromones.GetStrength(x, y, PheromoneType.FoodTrail);
                float home = pheromones.GetStrength(x, y, PheromoneType.HomeTrail);
                
                foodSum += food;
                homeSum += home;
                
                if (food > stats.MaxFoodTrail)
                    stats.MaxFoodTrail = food;
                if (home > stats.MaxHomeTrail)
                    stats.MaxHomeTrail = home;
                
                sampleCount++;
            }
        }

        if (sampleCount > 0)
        {
            stats.AvgFoodTrail = foodSum / sampleCount;
            stats.AvgHomeTrail = homeSum / sampleCount;
        }
    }

    private string GetAntThought(Ant ant, Grid grid, PheromoneLayer pheromones)
    {
        if (ant.IsDead)
        {
            return "XX Dead XX";
        }
        else if (ant.CarryingFood)
        {
            int nestDist = Math.Abs(ant.X - grid.NestX) + Math.Abs(ant.Y - grid.NestY);
            
            if (nestDist <= SimConfig.NestDetectionRange)
                return "Nest detected! Homing in...";
            
            float home = pheromones.GetStrength(ant.X, ant.Y, PheromoneType.HomeTrail);
            if (home > 1f)
                return $"Following home scent ({home:F0})";
            
            return "Dead reckoning to nest";
        }
        else
        {
            // Check for nearby food
            int range = SimConfig.FoodDetectionRange;
            for (int dx = -range; dx <= range; dx++)
            {
                for (int dy = -range; dy <= range; dy++)
                {
                    if (dx * dx + dy * dy <= range * range)
                    {
                        if (Simulation?.FoodManager.GetFoodAt(ant.X + dx, ant.Y + dy) > 0)
                            return "Food detected nearby!";
                    }
                }
            }

            float food = pheromones.GetStrength(ant.X, ant.Y, PheromoneType.FoodTrail);
            if (food > 1f)
                return $"Following food scent ({food:F0})";
            
            return "Wandering, exploring...";
        }
    }

    private string GetDirectionArrow(int dirIndex)
    {
        // Nerd Font Material Design arrow glyphs (nf-md-arrow_*)
        return dirIndex switch
        {   //  0=N, 1=NE, 2=E, 3=SE, 4=S, 5=SW, 6=W, 7=NW
            0 => "\U000F005D",  // North (md-arrow_up)
            1 => "\U000F005C",  // NE    (md-arrow_top_right)
            2 => "\U000F0054",  // East  (md-arrow_right)
            3 => "\U000F0043",  // SE    (md-arrow_bottom_right)
            4 => "\U000F0045",  // South (md-arrow_down)
            5 => "\U000F0042",  // SW    (md-arrow_bottom_left)
            6 => "\U000F004D",  // West  (md-arrow_left)
            7 => "\U000F005B",  // NW    (md-arrow_top_left)
            _ => "?"
        };
    }

    private string GetDirectionName(int dirIndex)
    {
        return dirIndex switch
        {   //  0=N, 1=NE, 2=E, 3=SE, 4=S, 5=SW, 6=W, 7=NW
            0 => "North",
            1 => "Northeast",
            2 => "East",
            3 => "Southeast",
            4 => "South",
            5 => "Southwest",
            6 => "West",
            7 => "Northwest",
            _ => "Unknown"
        };
    }
}
