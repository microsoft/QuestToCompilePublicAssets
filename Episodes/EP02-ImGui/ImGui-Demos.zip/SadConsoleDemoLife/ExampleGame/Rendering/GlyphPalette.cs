using ExampleGame.Simulation;

namespace ExampleGame.Rendering;

/// <summary>
/// Visual vocabulary for the colony simulation.
/// Defines glyphs and colors for all cell states.
/// </summary>
static class GlyphPalette
{
    // Glyphs
    // SadConsole's default font is CodePage 437 (glyph indices 0-255).
    // Use CP437 index values, NOT Unicode codepoints, for all glyphs.
    public const int Nest = 4; // CP437 index 4 = ♦ (diamond suit)
    public const int AntSearching = 'a';
    public const int AntCarrying = 'A';
    public const int Food = '%';
    public const int Empty = 0;
    public const int Wall = '#';

    // Base colors
    public static readonly Color NestColor = new Color(255, 200, 50);         // Bright gold
    public static readonly Color NestGlowColor = new Color(180, 120, 30);    // Dimmer gold for surrounding cells
    public static readonly Color NestBackgroundColor = new Color(80, 40, 10); // Warm brown background
    public static readonly Color AntSearchingColor = Color.White;
    public static readonly Color AntCarryingColor = Color.LimeGreen;
    public static readonly Color AntSelectedColor = Color.DeepPink;
    public static readonly Color AntDeadColor = Color.DarkGray;
    public static readonly Color FoodColor = Color.Green;
    public static readonly Color EmptyColor = new Color(40, 40, 40);         // Dark gray
    public static readonly Color WallColor = Color.Gray;
    public static readonly Color BackgroundColor = Color.Black;

    // Pheromone visualization colors (for blending)
    public static readonly Color FoodPheromoneColor = new Color(0, 100, 200);   // Blue tint
    public static readonly Color HomePheromoneColor = new Color(200, 180, 0);   // Yellow tint

    /// <summary>
    /// Get the glyph and foreground color for a terrain cell.
    /// </summary>
    public static (int glyph, Color foreground) GetTerrainAppearance(Simulation.CellType cellType)
    {
        return cellType switch
        {
            Simulation.CellType.Nest => (Nest, NestColor),
            Simulation.CellType.Wall => (Wall, WallColor),
            _ => (Empty, EmptyColor)
        };
    }

    /// <summary>
    /// Get the glyph and color for food.
    /// </summary>
    public static (int glyph, Color foreground) GetFoodAppearance()
    {
        return (Food, FoodColor);
    }

    /// <summary>
    /// Get the glyph and color for an ant.
    /// </summary>
    public static (int glyph, Color foreground) GetAntAppearance(Ant ant)
    {
        int glyph = ant.CarryingFood ? AntCarrying : AntSearching;
        Color color = ant.IsDead ? AntDeadColor :
                      ant.IsSelected ? AntSelectedColor :
                      ant.CarryingFood ? AntCarryingColor :
                                         AntSearchingColor;
        return (glyph, color);
    }

    /// <summary>
    /// Blend pheromone strength into a background color.
    /// </summary>
    public static Color BlendPheromoneBackground(float foodStrength, float homeStrength)
    {
        // Normalize strengths to reasonable visual range (0-1)
        float foodVis = Math.Clamp(foodStrength / 100f, 0f, 1f);
        float homeVis = Math.Clamp(homeStrength / 100f, 0f, 1f);

        // Blend pheromone colors into black background
        int r = (int)(FoodPheromoneColor.R * foodVis + HomePheromoneColor.R * homeVis);
        int g = (int)(FoodPheromoneColor.G * foodVis + HomePheromoneColor.G * homeVis);
        int b = (int)(FoodPheromoneColor.B * foodVis + HomePheromoneColor.B * homeVis);

        return new Color(
            Math.Clamp(r, 0, 255),
            Math.Clamp(g, 0, 255),
            Math.Clamp(b, 0, 255)
        );
    }
}
