Keys:

`?` Opens up a help menu.
`SPACE` pauses and unpauses the game.
`F12` opens the ImGui debug panel.
