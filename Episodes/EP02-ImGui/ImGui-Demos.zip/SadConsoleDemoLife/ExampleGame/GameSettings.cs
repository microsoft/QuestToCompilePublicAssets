﻿static class GameSettings
{
    public const int GAME_WIDTH = 216;
    public const int GAME_HEIGHT = 60;    
}
