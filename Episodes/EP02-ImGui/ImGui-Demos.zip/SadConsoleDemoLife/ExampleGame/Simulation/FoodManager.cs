namespace ExampleGame.Simulation;

/// <summary>
/// Manages food spawning, pickup, and collection.
/// </summary>
public class FoodManager
{
    private readonly int[,] _foodQuantity;
    private readonly int _width;
    private readonly int _height;
    private readonly Random _random;

    public int TotalFoodCollected { get; private set; }

    public FoodManager(int width, int height)
    {
        _width = width;
        _height = height;
        _foodQuantity = new int[width, height];
        _random = new Random();
        TotalFoodCollected = 0;
    }

    /// <summary>
    /// Get food quantity at a position.
    /// </summary>
    public int GetFoodAt(int x, int y)
    {
        if (x < 0 || x >= _width || y < 0 || y >= _height) return 0;
        return _foodQuantity[x, y];
    }

    /// <summary>
    /// Set food quantity at a position.
    /// </summary>
    public void SetFoodAt(int x, int y, int amount, Grid grid)
    {
        if (grid.IsInBounds(x, y) && grid.GetCell(x, y) == CellType.Empty)
            _foodQuantity[x, y] = amount;
    }

    /// <summary>
    /// Initialize food clusters at random positions.
    /// </summary>
    public void InitializeFood(Grid grid)
    {
        for (int i = 0; i < SimConfig.FoodClusterCount; i++)
        {
            int attempts = 0;
            while (attempts < 100)
            {
                int centerX = _random.Next(_width);
                int centerY = _random.Next(_height);

                // Don't spawn on nest
                if (centerX == grid.NestX && centerY == grid.NestY)
                {
                    attempts++;
                    continue;
                }

                SpawnFoodCluster(grid, centerX, centerY, SimConfig.FoodPerCluster);
                break;
            }
        }
    }

    /// <summary>
    /// Spawn a food cluster around a center position.
    /// </summary>
    public void SpawnFoodCluster(Grid grid, int centerX, int centerY, int totalFood)
    {
        int remaining = totalFood;
        int radius = 3;

        for (int x = centerX - radius; x <= centerX + radius && remaining > 0; x++)
        {
            for (int y = centerY - radius; y <= centerY + radius && remaining > 0; y++)
            {
                if (!grid.IsInBounds(x, y)) continue;
                if (grid.GetCell(x, y) != CellType.Empty) continue;

                // Distance-based distribution
                int dx = x - centerX;
                int dy = y - centerY;
                int distSq = dx * dx + dy * dy;
                if (distSq > radius * radius) continue;

                int amount = Math.Min(remaining, _random.Next(1, 5));
                _foodQuantity[x, y] += amount;
                remaining -= amount;
            }
        }
    }

    /// <summary>
    /// Try to pick up food at a position. Returns true if food was picked up.
    /// </summary>
    public bool TryPickup(int x, int y)
    {
        if (x < 0 || x >= _width || y < 0 || y >= _height) return false;
        if (_foodQuantity[x, y] > 0)
        {
            _foodQuantity[x, y]--;
            return true;
        }
        return false;
    }

    /// <summary>
    /// Try to drop off food at nest. Returns true if dropoff succeeded.
    /// </summary>
    public bool TryDropoff(int x, int y, Grid grid)
    {
        if (x == grid.NestX && y == grid.NestY)
        {
            TotalFoodCollected++;
            return true;
        }
        return false;
    }

    /// <summary>
    /// Calculate total food remaining in the world.
    /// </summary>
    public int GetTotalFoodRemaining()
    {
        int total = 0;
        for (int x = 0; x < _width; x++)
        {
            for (int y = 0; y < _height; y++)
            {
                total += _foodQuantity[x, y];
            }
        }
        return total;
    }
}
