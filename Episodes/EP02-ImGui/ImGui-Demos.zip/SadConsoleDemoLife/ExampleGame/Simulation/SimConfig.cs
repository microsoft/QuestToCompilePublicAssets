namespace ExampleGame.Simulation;

/// <summary>
/// All tunable simulation parameters in one place.
/// </summary>
public static class SimConfig
{
    // Grid dimensions
    public const int GridWidth = 216;
    public const int GridHeight = 60;

    // Ant population
    public const int MaxAnts = 1000;
    public const int InitialAnts = 50;

    // Pheromone mechanics
    public const float PheromoneDecayRate = 0.02f;
    public const float PheromoneDiffusionRate = 0.1f;
    public const float FoodPheromoneStrength = 50f;
    public const float HomePheromoneStrength = 50f;
    public const int HomeTrailMaxRange = 150;
    public const int FoodTrailMaxRange = 150;

    // Ant behavior
    public const int AntSenseConeSize = 3;
    public const float RandomTurnChance = 0.1f;
    public const int FoodDetectionRange = 5;
    public const int NestDetectionRange = 10;

    // Food spawning
    public const int FoodClusterCount = 5;
    public const int FoodPerCluster = 50;

    // Simulation timing
    public const int SimTicksPerSecond = 10;
}
