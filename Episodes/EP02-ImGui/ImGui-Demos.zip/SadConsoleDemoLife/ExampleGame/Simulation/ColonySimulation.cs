namespace ExampleGame.Simulation;

/// <summary>
/// The main simulation orchestrator. Owns all simulation components and coordinates their updates.
/// </summary>
public class ColonySimulation
{
    private readonly Grid _grid;
    private readonly PheromoneLayer _pheromoneLayer;
    private readonly AntManager _antManager;
    private readonly FoodManager _foodManager;

    public Grid Grid => _grid;
    public PheromoneLayer PheromoneLayer => _pheromoneLayer;
    public AntManager AntManager => _antManager;
    public FoodManager FoodManager => _foodManager;

    public ColonySimulation()
    {
        _grid = new Grid(SimConfig.GridWidth, SimConfig.GridHeight);
        _pheromoneLayer = new PheromoneLayer(
            SimConfig.GridWidth,
            SimConfig.GridHeight,
            SimConfig.PheromoneDecayRate,
            SimConfig.PheromoneDiffusionRate
        );
        _antManager = new AntManager();
        _foodManager = new FoodManager(SimConfig.GridWidth, SimConfig.GridHeight);
    }

    /// <summary>
    /// Initialize the simulation: spawn initial ants and food.
    /// </summary>
    public void Initialize()
    {
        // Spawn initial ants at nest
        for (int i = 0; i < SimConfig.InitialAnts; i++)
        {
            _antManager.SpawnAnt(_grid.NestX, _grid.NestY);
        }

        // Initialize food clusters
        _foodManager.InitializeFood(_grid);
    }

    /// <summary>
    /// Process one simulation tick.
    /// </summary>
    public void Tick()
    {
        // Update all ants
        _antManager.TickAll(_grid, _pheromoneLayer, _foodManager);

        // Update pheromones (decay and diffusion)
        _pheromoneLayer.Tick();

        // Spawn new ants if below max
        if (_antManager.Ants.Count < SimConfig.MaxAnts)
        {
            // Spawn rate: 1 ant per second (every 10 ticks at 10 ticks/sec)
            if (_antManager.Ants.Count % 10 == 0)
            {
                _antManager.SpawnAnt(_grid.NestX, _grid.NestY);
            }
        }
    }
}
