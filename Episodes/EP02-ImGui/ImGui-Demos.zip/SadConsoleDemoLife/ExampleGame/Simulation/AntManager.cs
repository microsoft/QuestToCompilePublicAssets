namespace ExampleGame.Simulation;

/// <summary>
/// Manages all ants and their behavior logic.
/// </summary>
public class AntManager
{
    private readonly List<Ant> _ants;
    private readonly Random _random;
    private readonly AntNameGenerator _nameGenerator;

    public int _selectedAntIndex;

    public IReadOnlyList<Ant> Ants => _ants;

    public AntManager()
    {
        _ants = new List<Ant>();
        _random = new Random();
        _nameGenerator = new AntNameGenerator();
    }

    public void SelectAnt(int index)
    {
        UnselectAnt();

        _selectedAntIndex = index;
        if (_selectedAntIndex < 0 || _selectedAntIndex >= _ants.Count)
        {
            _selectedAntIndex = -1;
            return;
        }

        Ant ant = _ants[_selectedAntIndex];
        ant.IsSelected = true;
        _ants[_selectedAntIndex] = ant;
    }

    public void UnselectAnt()
    {
        if (_selectedAntIndex < 0 || _selectedAntIndex >= _ants.Count)
            return;

        Ant ant = _ants[_selectedAntIndex];
        ant.IsSelected = false;
        _ants[_selectedAntIndex] = ant;

        _selectedAntIndex = -1;
    }

    public void KillAnt(int index)
    {
        Ant ant = _ants[index];
        ant.IsDead = true;
        _ants[_selectedAntIndex] = ant;
    }

    /// <summary>
    /// Spawn a new ant at the nest position.
    /// </summary>
    public void SpawnAnt(int nestX, int nestY)
    {
        string name = _nameGenerator.GenerateUniqueName();
        var ant = new Ant(nestX, nestY, Direction.GetRandom(), name);
        _ants.Add(ant);
    }

    /// <summary>
    /// Tick all ants: run behavior logic for each ant.
    /// </summary>
    public void TickAll(Grid grid, PheromoneLayer pheromoneLayer, FoodManager foodManager)
    {
        for (int i = 0; i < _ants.Count; i++)
        {
            var ant = _ants[i];
            TickAnt(ref ant, grid, pheromoneLayer, foodManager);
            _ants[i] = ant;
        }
    }

    private void TickAnt(ref Ant ant, Grid grid, PheromoneLayer pheromoneLayer, FoodManager foodManager)
    {
        if (ant.IsDead)
            return;

        ant.StepsSinceNest++;

        // Reset distance budget whenever at the nest
        if (ant.X == grid.NestX && ant.Y == grid.NestY)
            ant.StepsSinceNest = 0;

        // Drop off food BEFORE depositing pheromones to avoid FoodTrail hotspot at nest
        if (ant.CarryingFood && ant.X == grid.NestX && ant.Y == grid.NestY)
        {
            foodManager.TryDropoff(ant.X, ant.Y, grid);
            ant.CarryingFood = false;
            ant.DirectionIndex = (ant.DirectionIndex + 4) % 8; // Turn 180° back toward food source
            ant.StepsSinceNest = 0;
            // Skip DecideDirection this tick to preserve the 180° turn
            MoveForward(ref ant, grid);
            return;
        }

        // Deposit pheromones
        if (ant.CarryingFood)
        {
            ant.StepsSinceFood++;
            // Strength decays with distance from food source, creating gradient toward food
            float foodStrength = SimConfig.FoodPheromoneStrength * Math.Max(0f, 1f - (float)ant.StepsSinceFood / SimConfig.FoodTrailMaxRange);
            if (foodStrength > 0f)
            {
                pheromoneLayer.Deposit(ant.X, ant.Y, foodStrength, PheromoneType.FoodTrail);
            }
        }
        else
        {
            // Deposit home trail when searching (signals "nest is this way" to returning ants)
            float homeStrength = SimConfig.HomePheromoneStrength * Math.Max(0f, 1f - (float)ant.StepsSinceNest / SimConfig.HomeTrailMaxRange);
            if (homeStrength > 0f)
            {
                pheromoneLayer.Deposit(ant.X, ant.Y, homeStrength, PheromoneType.HomeTrail);
            }
        }

        // Check if at food without carrying
        if (!ant.CarryingFood && foodManager.TryPickup(ant.X, ant.Y))
        {
            ant.CarryingFood = true;
            ant.StepsSinceFood = 0;
            ant.DirectionIndex = (ant.DirectionIndex + 4) % 8; // Turn around 180 degrees
        }

        // Sense and move
        DecideDirection(ref ant, grid, pheromoneLayer, foodManager);
        MoveForward(ref ant, grid);
    }

    private void DecideDirection(ref Ant ant, Grid grid, PheromoneLayer pheromoneLayer, FoodManager foodManager)
    {
        if (ant.CarryingFood)
        {
            // Navigate directly toward the nest with slight random perturbation
            int idealDir = Direction.DirectionToward(ant.X, ant.Y, grid.NestX, grid.NestY);
            double roll = _random.NextDouble();
            if (roll < 0.15)
                idealDir = Direction.TurnLeft45(idealDir);
            else if (roll < 0.30)
                idealDir = Direction.TurnRight45(idealDir);
            ant.DirectionIndex = idealDir;
            return;
        }

        // Searching: random turn chance
        if (_random.NextDouble() < SimConfig.RandomTurnChance)
        {
            if (_random.Next(2) == 0)
                ant.DirectionIndex = Direction.TurnLeft45(ant.DirectionIndex);
            else
                ant.DirectionIndex = Direction.TurnRight45(ant.DirectionIndex);
            return;
        }

        // Sense 3-cell cone for FoodTrail
        var cone = Direction.GetSenseCone(ant.X, ant.Y, ant.DirectionIndex);

        float leftStrength = grid.IsInBounds(cone[0].x, cone[0].y)
            ? pheromoneLayer.GetStrength(cone[0].x, cone[0].y, PheromoneType.FoodTrail)
            : 0f;
        float forwardStrength = grid.IsInBounds(cone[1].x, cone[1].y)
            ? pheromoneLayer.GetStrength(cone[1].x, cone[1].y, PheromoneType.FoodTrail)
            : 0f;
        float rightStrength = grid.IsInBounds(cone[2].x, cone[2].y)
            ? pheromoneLayer.GetStrength(cone[2].x, cone[2].y, PheromoneType.FoodTrail)
            : 0f;

        // Turn toward strongest pheromone
        if (leftStrength > forwardStrength && leftStrength > rightStrength && leftStrength > 1f)
            ant.DirectionIndex = Direction.TurnLeft45(ant.DirectionIndex);
        else if (rightStrength > forwardStrength && rightStrength > leftStrength && rightStrength > 1f)
            ant.DirectionIndex = Direction.TurnRight45(ant.DirectionIndex);
    }

    private void MoveForward(ref Ant ant, Grid grid)
    {
        var (dx, dy) = Direction.GetForward(ant.DirectionIndex);
        int newX = ant.X + dx;
        int newY = ant.Y + dy;

        // Check bounds and walls
        if (grid.IsInBounds(newX, newY) && grid.GetCell(newX, newY) != CellType.Wall)
        {
            ant.X = newX;
            ant.Y = newY;
        }
        else
        {
            // Hit wall or boundary, turn around
            ant.DirectionIndex = Direction.GetRandom();
        }
    }
}
