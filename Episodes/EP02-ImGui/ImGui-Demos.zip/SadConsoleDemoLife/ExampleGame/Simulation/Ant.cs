namespace ExampleGame.Simulation;

/// <summary>
/// Ant data structure. Using struct for cache-friendly memory layout.
/// </summary>
public struct Ant
{
    public int X;
    public int Y;
    public int DirectionIndex; // 0-7
    public bool CarryingFood;
    public bool IsSelected;
    public bool IsDead;
    public int StepsSinceNest;
    public int StepsSinceFood;
    public string Name;

    public Ant(int x, int y, int directionIndex, string name)
    {
        X = x;
        Y = y;
        DirectionIndex = directionIndex;
        CarryingFood = false;
        StepsSinceNest = 0;
        StepsSinceFood = 0;
        Name = name;
    }
}
