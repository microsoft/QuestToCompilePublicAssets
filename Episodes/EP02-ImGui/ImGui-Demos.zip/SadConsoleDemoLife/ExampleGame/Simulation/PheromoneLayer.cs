namespace ExampleGame.Simulation;

/// <summary>
/// Type of pheromone trail.
/// </summary>
public enum PheromoneType
{
    FoodTrail = 0,
    HomeTrail = 1
}

/// <summary>
/// Manages two separate pheromone layers with decay and diffusion.
/// Uses double-buffered arrays to avoid read-write conflicts during diffusion.
/// </summary>
public class PheromoneLayer
{
    private readonly int _width;
    private readonly int _height;
    private readonly float _decayRate;
    private readonly float _diffusionRate;

    private float[,] _foodTrail;
    private float[,] _homeTrail;
    private float[,] _foodTrailBuffer;
    private float[,] _homeTrailBuffer;

    public PheromoneLayer(int width, int height, float decayRate, float diffusionRate)
    {
        _width = width;
        _height = height;
        _decayRate = decayRate;
        _diffusionRate = diffusionRate;

        _foodTrail = new float[width, height];
        _homeTrail = new float[width, height];
        _foodTrailBuffer = new float[width, height];
        _homeTrailBuffer = new float[width, height];
    }

    /// <summary>
    /// Deposit pheromone at a position.
    /// </summary>
    public void Deposit(int x, int y, float amount, PheromoneType type)
    {
        if (x < 0 || x >= _width || y < 0 || y >= _height) return;

        if (type == PheromoneType.FoodTrail)
            _foodTrail[x, y] = Math.Min(_foodTrail[x, y] + amount, 255f);
        else
            _homeTrail[x, y] = Math.Min(_homeTrail[x, y] + amount, 255f);
    }

    /// <summary>
    /// Get pheromone strength at a position.
    /// </summary>
    public float GetStrength(int x, int y, PheromoneType type)
    {
        if (x < 0 || x >= _width || y < 0 || y >= _height) return 0f;

        return type == PheromoneType.FoodTrail ? _foodTrail[x, y] : _homeTrail[x, y];
    }

    /// <summary>
    /// Process one tick: decay all values, then diffuse.
    /// </summary>
    public void Tick()
    {
        DecayAndDiffuse(_foodTrail, _foodTrailBuffer);
        DecayAndDiffuse(_homeTrail, _homeTrailBuffer);
    }

    private void DecayAndDiffuse(float[,] source, float[,] buffer)
    {
        // Decay phase
        for (int x = 0; x < _width; x++)
        {
            for (int y = 0; y < _height; y++)
            {
                source[x, y] *= (1f - _decayRate);
            }
        }

        // Diffusion phase using double-buffer
        for (int x = 0; x < _width; x++)
        {
            for (int y = 0; y < _height; y++)
            {
                float sum = source[x, y];
                int count = 1;

                // 4-neighbor averaging
                if (x > 0) { sum += source[x - 1, y]; count++; }
                if (x < _width - 1) { sum += source[x + 1, y]; count++; }
                if (y > 0) { sum += source[x, y - 1]; count++; }
                if (y < _height - 1) { sum += source[x, y + 1]; count++; }

                float average = sum / count;
                buffer[x, y] = source[x, y] * (1f - _diffusionRate) + average * _diffusionRate;
            }
        }

        // Copy buffer back to source
        Array.Copy(buffer, source, buffer.Length);
    }
}
