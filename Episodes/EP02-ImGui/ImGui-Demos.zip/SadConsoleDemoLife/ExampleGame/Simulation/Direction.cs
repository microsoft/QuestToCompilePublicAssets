namespace ExampleGame.Simulation;

/// <summary>
/// 8-direction helpers with pre-computed offsets.
/// Directions: 0=N, 1=NE, 2=E, 3=SE, 4=S, 5=SW, 6=W, 7=NW
/// </summary>
public static class Direction
{
    private static readonly int[] DX = { 0, 1, 1, 1, 0, -1, -1, -1 };
    private static readonly int[] DY = { -1, -1, 0, 1, 1, 1, 0, -1 };

    private static readonly Random Random = new Random();

    /// <summary>
    /// Get forward offset for a direction index (0-7).
    /// </summary>
    public static (int dx, int dy) GetForward(int directionIndex)
    {
        return (DX[directionIndex], DY[directionIndex]);
    }

    /// <summary>
    /// Turn left 45 degrees.
    /// </summary>
    public static int TurnLeft45(int directionIndex)
    {
        return (directionIndex + 7) % 8;
    }

    /// <summary>
    /// Turn right 45 degrees.
    /// </summary>
    public static int TurnRight45(int directionIndex)
    {
        return (directionIndex + 1) % 8;
    }

    /// <summary>
    /// Get a random direction index (0-7).
    /// </summary>
    public static int GetRandom()
    {
        return Random.Next(8);
    }

    /// <summary>
    /// Compute the discrete 8-direction index pointing from (fromX, fromY) toward (toX, toY).
    /// Returns a random direction if from == to.
    /// </summary>
    public static int DirectionToward(int fromX, int fromY, int toX, int toY)
    {
        int dx = toX - fromX;
        int dy = toY - fromY;
        if (dx == 0 && dy == 0) return GetRandom();

        double angle = Math.Atan2(dy, dx);
        double normalized = (angle + Math.PI / 2) / (Math.PI / 4);
        int dir = ((int)Math.Round(normalized) % 8 + 8) % 8;
        return dir;
    }

    /// <summary>
    /// Get the 3-cell sense cone: forward-left, forward, forward-right.
    /// Returns array of (x, y) positions relative to current position.
    /// </summary>
    public static (int x, int y)[] GetSenseCone(int x, int y, int directionIndex)
    {
        var forward = GetForward(directionIndex);
        var left = GetForward(TurnLeft45(directionIndex));
        var right = GetForward(TurnRight45(directionIndex));

        return new[]
        {
            (x + left.dx, y + left.dy),
            (x + forward.dx, y + forward.dy),
            (x + right.dx, y + right.dy)
        };
    }
}
