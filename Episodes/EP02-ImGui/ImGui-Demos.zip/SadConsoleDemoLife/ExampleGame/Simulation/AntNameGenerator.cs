namespace ExampleGame.Simulation;

/// <summary>
/// Generates unique random names for ants using Adjective + Noun combinations.
/// </summary>
public class AntNameGenerator
{
    private static readonly string[] Adjectives =
    {
        "Silly", "Brave", "Dizzy", "Sneaky", "Jolly", "Grumpy", "Lazy", "Mighty",
        "Tiny", "Swift", "Angry", "Happy", "Clever", "Bold", "Calm", "Eager",
        "Fancy", "Gentle", "Hasty", "Keen", "Lucky", "Merry", "Noble", "Proud",
        "Quick", "Rowdy", "Sly", "Tough", "Wary", "Wild", "Zappy", "Bouncy",
        "Cranky", "Daring", "Fluffy", "Goofy", "Jumpy", "Peppy", "Zippy", "Snappy"
    };

    private static readonly string[] Nouns =
    {
        "Pants", "Spoon", "Muffin", "Pickle", "Nugget", "Waffle", "Boots", "Noodle",
        "Biscuit", "Turnip", "Pudding", "Crumpet", "Dumpling", "Pebble", "Sprocket", "Widget",
        "Wobble", "Tadpole", "Acorn", "Button", "Clover", "Doodle", "Ember", "Fidget",
        "Goblin", "Hamster", "Igloo", "Jumble", "Kettle", "Lemon", "Marble", "Napkin",
        "Orange", "Pretzel", "Quilt", "Raisin", "Socks", "Taco", "Urchin", "Vest"
    };

    private readonly Random _random;
    private readonly HashSet<string> _usedNames;

    public AntNameGenerator()
    {
        _random = new Random();
        _usedNames = new HashSet<string>();
    }

    /// <summary>
    /// Generate a unique name for an ant. Regenerates if collision occurs.
    /// </summary>
    public string GenerateUniqueName()
    {
        string name;
        int attempts = 0;
        const int maxAttempts = 1000;

        do
        {
            string adjective = Adjectives[_random.Next(Adjectives.Length)];
            string noun = Nouns[_random.Next(Nouns.Length)];
            name = $"{adjective} {noun}";
            attempts++;

            if (attempts >= maxAttempts)
            {
                // Fallback: append number if we've exhausted combinations
                name = $"{adjective} {noun} {_random.Next(1000, 9999)}";
                break;
            }
        }
        while (_usedNames.Contains(name));

        _usedNames.Add(name);
        return name;
    }

    /// <summary>
    /// Remove a name from the used set (e.g., if an ant is removed).
    /// </summary>
    public void ReleaseName(string name)
    {
        _usedNames.Remove(name);
    }
}
