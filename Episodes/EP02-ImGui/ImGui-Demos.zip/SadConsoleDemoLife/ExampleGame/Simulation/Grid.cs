namespace ExampleGame.Simulation;

/// <summary>
/// Cell types in the world grid.
/// </summary>
public enum CellType
{
    Empty = 0,
    Nest = 1,
    Wall = 2
}

/// <summary>
/// The world grid containing terrain data.
/// </summary>
public class Grid
{
    private readonly CellType[,] _terrain;

    public int Width { get; }
    public int Height { get; }
    public int NestX { get; }
    public int NestY { get; }

    public Grid(int width, int height)
    {
        Width = width;
        Height = height;
        _terrain = new CellType[width, height];

        // Place nest at center
        NestX = width / 2;
        NestY = height / 2;
        _terrain[NestX, NestY] = CellType.Nest;
    }

    /// <summary>
    /// Check if coordinates are within grid bounds.
    /// </summary>
    public bool IsInBounds(int x, int y)
    {
        return x >= 0 && x < Width && y >= 0 && y < Height;
    }

    /// <summary>
    /// Get cell type at position.
    /// </summary>
    public CellType GetCell(int x, int y)
    {
        if (!IsInBounds(x, y)) return CellType.Wall;
        return _terrain[x, y];
    }

    /// <summary>
    /// Set cell type at position.
    /// </summary>
    public void SetCell(int x, int y, CellType cellType)
    {
        if (IsInBounds(x, y))
        {
            _terrain[x, y] = cellType;
        }
    }
}
