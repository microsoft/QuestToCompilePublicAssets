﻿using Hexa.NET.ImGui;
using Hexa.NET.ImGui.Utilities;
using SadConsole.Configuration;

Directory.SetCurrentDirectory(AppContext.BaseDirectory);

Settings.WindowTitle = "SimAnt Colony Simulation";

Builder
    .GetBuilder()
    .SetWindowSizeInCells(GameSettings.GAME_WIDTH, GameSettings.GAME_HEIGHT)
    .SetStartingScreen<ExampleGame.Rendering.SimulationScreen>()
    .IsStartingScreenFocused(true)
    .ConfigureFonts(true)
    .EnableImGui(startupAction: (imguiComponent) =>
    {
        ImGui.GetIO().Fonts.Clear();
        imguiComponent.ImGuiRenderer.SetDefaultFont(
            new ImGuiFontBuilder(ImGui.GetIO().Fonts)
                .SetOption(config =>
                {
                    config.FontBuilderFlags |= (uint)ImGuiFreeTypeBuilderFlags.LoadColor;
                })
                .AddFontFromFileTTF("CousineNerdFont-Regular.ttf", 22f, [0x01, 0xFFFFF])
                .AddFontFromFileTTF("CousineNerdFont-Regular.ttf", 16f, [0x01, 0xFFFFF])
                .Build()
        );

        imguiComponent.UIComponents.Add(new ExampleGame.Rendering.DebugWindow());
    })
    .Run();
