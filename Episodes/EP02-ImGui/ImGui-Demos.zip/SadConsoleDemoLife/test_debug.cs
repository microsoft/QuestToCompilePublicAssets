using ExampleGame.Simulation;

var grid = new Grid(50, 30);
var pheromoneLayer = new PheromoneLayer(50, 30, 0f, 0f);
var foodManager = new FoodManager(50, 30);
var manager = new AntManager();

int startX = grid.NestX + 10;
Console.WriteLine($"NestX: {grid.NestX}, NestY: {grid.NestY}, StartX: {startX}");

manager.SpawnAnt(startX, grid.NestY);

for (int i = 0; i < 20; i++)
{
    var ant = manager.Ants[0];
    Console.WriteLine($"Tick {i}: X={ant.X}, Y={ant.Y}, Steps={ant.StepsSinceNest}, CarryingFood={ant.CarryingFood}, AtNest={ant.X == grid.NestX && ant.Y == grid.NestY}");
    
    float strength = pheromoneLayer.GetStrength(ant.X, ant.Y, PheromoneType.HomeTrail);
    Console.WriteLine($"  HomeTrail at position: {strength:F2}");
    
    manager.TickAll(grid, pheromoneLayer, foodManager);
}
